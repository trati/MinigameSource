﻿using UnityEngine;
using System.Collections;

/// <summary>
/// Constants.
/// </summary>
public class Constants 
{
	public const string REVIEW_URL = "http://sharecode.vn/thanh-vien/quangtien-36570.htm";
	public const string MOREAPPS_URL = "http://sharecode.vn/thanh-vien/quangtien-36570.htm";
}
