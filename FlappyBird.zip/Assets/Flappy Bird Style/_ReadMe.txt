A Flappy Bird Style Game

This game is a very simple representation of a tap and play game similar to "Flappy Bird".

-

For more learn material, please check the learn section of our website:

http://unity3d.com/learn