namespace GoogleMobileAds.Api
{
    // The gender of the user.
    public enum Gender
    {
        Unknown = 0,
        Male = 1,
        Female = 2
    }
}
