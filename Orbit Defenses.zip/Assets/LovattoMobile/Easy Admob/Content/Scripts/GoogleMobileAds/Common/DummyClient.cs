using UnityEngine;
using GoogleMobileAds.Api;

namespace GoogleMobileAds.Common
{
    internal class DummyClient : IGoogleMobileAdsBannerClient, IGoogleMobileAdsInterstitialClient
    {
        public DummyClient(IAdListener listener)
        {
            Debug.Log("Created DummyClient");
        }

        public void CreateBannerView(string adUnitId, AdSize adSize, AdPosition position)
        {
            Debug.Log("Create Banner View");
        }

        public void LoadAd(AdRequest request)
        {
            Debug.Log("Load Ad");
        }

        public void ShowBannerView()
        {
            Debug.Log("Show Banner View");
        }

        public void HideBannerView()
        {
            Debug.Log("Hide Banner View");
        }

        public void DestroyBannerView()
        {
            Debug.Log("Destroy Banner View");
        }

        public void CreateInterstitialAd(string adUnitId) {
            Debug.Log("Create Intersitial Ad");
        }

        public bool IsLoaded() {
            Debug.Log("Is Loaded");
            return true;
        }

        public void ShowInterstitial() {
            Debug.Log("Show Interstitial");
        }

        public void DestroyInterstitial() {
            Debug.Log("Destroy Interstitial");
        }

        public void SetInAppPurchaseParams(IInAppPurchaseListener listener, string androidPublicKey)
        {
            Debug.Log("Set In App PurchaseParams");
            bl_LogText.LogText("Set In App PurchaseParams");
        }
    }
}
