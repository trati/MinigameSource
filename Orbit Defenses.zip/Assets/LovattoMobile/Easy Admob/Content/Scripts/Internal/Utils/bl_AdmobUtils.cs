﻿using UnityEngine;

public static class bl_AdmobUtils
{

    /// <summary>
    /// 
    /// </summary>
    /// <param name="Name"></param>
    /// <returns></returns>
    public static bl_Admob GetAdmob(string Name,bool ischeck = false)
    {
        bl_Admob[] all = GameObject.FindObjectsOfType<bl_Admob>();
        if(all.Length > 0)
        {
            foreach(bl_Admob ad in all)
            {
                if(ad.ADSName == Name)
                {
                    return ad;
                }
            }
            Debug.LogWarning("Not found any admob with this name, return the first.");
            return all[0];
        }
        if (!ischeck)
        {
            Debug.LogWarning("Not found any admob script in this scene, return null. ignore if call in first time");
        }
        return null;
    }


    /// <summary>
    /// is Plataform mobile?
    /// </summary>
    public static bool IsMobile
    {
        get
        {
            bool mobile = false;
#if !UNITY_EDITOR && UNITY_ANDROID || UNITY_IPHONE || UNITY_IOS 
            mobile = true;
#endif
            return mobile;
        }
    }

}