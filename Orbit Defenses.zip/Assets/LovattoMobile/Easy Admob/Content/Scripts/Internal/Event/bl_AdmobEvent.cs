﻿using UnityEngine;
using System;
using GoogleMobileAds.Api;

public class bl_AdmobEvent
{
    public delegate void HandleAdLoadedDelegate(object sender, EventArgs args);
    public static HandleAdLoadedDelegate OnHandleAdLoaded;

    public delegate void HandleAdFailedToLoadDelegate(object sender, AdFailedToLoadEventArgs args);
    public static HandleAdFailedToLoadDelegate OnHandleAdFailedToLoad;

    public delegate void HandleAdOpenedDelegate(object sender, EventArgs args);
    public static HandleAdOpenedDelegate OnHandleAdOpened;

    public delegate void HandleAdClosingDelegate(object sender, EventArgs args);
    public static HandleAdClosingDelegate OnHandleAdClosing;

    public delegate void HandleAdClosedDelegate(object sender, EventArgs args);
    public static HandleAdClosedDelegate OnHandleAdClosed;

    public delegate void HandleAdLeftApplicationDelegate(object sender, EventArgs args);
    public static HandleAdLeftApplicationDelegate OnHandleAdLeftApplication;


    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="args"></param>
    public static void HandleAdLoaded(object sender, EventArgs args)
    {
        if(OnHandleAdLoaded != null)
        {
            OnHandleAdLoaded(sender, args);
        }
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="args"></param>
    public static void HandleAdFailedToLoad(object sender, AdFailedToLoadEventArgs args)
    {
        if (OnHandleAdFailedToLoad != null)
        {
            OnHandleAdFailedToLoad(sender, args);
        }
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="args"></param>
    public static void HandleAdOpened(object sender, EventArgs args)
    {
        if (OnHandleAdOpened != null)
        {
            OnHandleAdOpened(sender, args);
        }
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="args"></param>
    public static void HandleAdClosing(object sender, EventArgs args)
    {
        if (OnHandleAdClosing != null)
        {
            OnHandleAdClosing(sender, args);
        }
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="args"></param>
    public static void HandleAdClosed(object sender, EventArgs args)
    {
        if (OnHandleAdClosed != null)
        {
            OnHandleAdClosed(sender, args);
        }
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="args"></param>
    public static void HandleAdLeftApplication(object sender, EventArgs args)
    {
        if (OnHandleAdLeftApplication != null)
        {
            OnHandleAdLeftApplication(sender, args);
        }
    }
}