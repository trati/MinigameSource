﻿public enum AdSizeEnum 
{
    Banner,
    IABBanner,
    Leaderboard,
    MediumRectangle,
    SmartBanner,
    Custom,
}