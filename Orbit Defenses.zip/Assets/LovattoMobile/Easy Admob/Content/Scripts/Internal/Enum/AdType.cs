﻿public enum AdType
{
    Banner,
    Interstitial,
    InAppPurchase,
}