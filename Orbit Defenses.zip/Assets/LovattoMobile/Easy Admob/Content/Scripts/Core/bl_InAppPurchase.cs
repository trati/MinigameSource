﻿using UnityEngine;
using GoogleMobileAds.Api;

public class bl_InAppPurchase : IInAppPurchaseHandler
{
    // TODO: Insert your app's valid skus here
    private string[] validSkus = { "no_ads_orbit_defense" };
    private string PublicKey = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAkcKdgq+i/y0Vt3j23sPLyl6DLexCYyYcLrZMwY5hvZwSgNO/wBZo6zjY/ARo35OlxL85qaUAk3b430Z/CUnl4nyLYGKSi4M7wzmbnjQgLRUJAQV6QUMT4zaep0TX7bdVJCc46Z22sN+E18wmQ5KZmpjrpvDTaW/ZZePCTcGmaXN3+8Cll9Dxckkpa6GP59+4h/p60y5Mld1TxdGwEuDxz4T+mvBdkJexJA25xDO19aKw7dryOx5iA/T9wUWGHVCmoJiKRt+dHhSejEcLJ4xXSQ9C8prsEmBmCIdZ+Zcshp4yzf4Eu1AcYgo+csbqNyXUZDv8qPbOShRDh+i+3AvexwIDAQAB";

    public void Init(string[] skus,string publicKey)
    {
        validSkus = skus;
        PublicKey = publicKey;
    }

    // Will only be sent on a success.
    public void OnInAppPurchaseFinished(IInAppPurchaseResult result)
    {
        result.FinishPurchase();
        bl_LogText.LogText("Purchase Succeeded!");
    }

    // Check SKU against valid SKUs.
    public bool IsValidPurchase(string sku)
    {
        foreach (string vs in validSkus)
        {
            if (sku == vs)
            {
                return true;
            }
        };
        Debug.Log("SKU Not found!: " + sku);
        bl_LogText.LogText("SKU Not found!: " + sku);
        return false;
    }

    // Return the app's public key.
    public string AndroidPublicKey
    {
        get { return PublicKey; }
    }
}