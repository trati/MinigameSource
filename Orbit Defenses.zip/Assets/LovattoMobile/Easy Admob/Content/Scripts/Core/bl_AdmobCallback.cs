﻿//Use this script as reference of ad callback
//this messages are called when one of event is invoke
//you need add the script listener for receive it in one script

using UnityEngine;
using System;
using GoogleMobileAds.Api;

public class bl_AdmobCallback : MonoBehaviour
{

    /// <summary>
    /// Add this script as listener for receive the events
    /// </summary>
    void OnEnable()
    {
        bl_AdmobEvent.OnHandleAdOpened += HandleAdOpened;
        bl_AdmobEvent.OnHandleAdLoaded += HandleAdLoaded;
        bl_AdmobEvent.OnHandleAdLeftApplication += HandleAdLeftApplication;
        bl_AdmobEvent.OnHandleAdFailedToLoad += HandleAdFailedToLoad;
        bl_AdmobEvent.OnHandleAdClosing += HandleAdClosing;
        bl_AdmobEvent.OnHandleAdClosed += HandleAdClosed;
    }

    /// <summary>
    /// When desactive this gameobject
    /// remove this listeners from event.
    /// </summary>
    void OnDisable()
    {
        bl_AdmobEvent.OnHandleAdOpened -= HandleAdOpened;
        bl_AdmobEvent.OnHandleAdLoaded -= HandleAdLoaded;
        bl_AdmobEvent.OnHandleAdLeftApplication -= HandleAdLeftApplication;
        bl_AdmobEvent.OnHandleAdFailedToLoad -= HandleAdFailedToLoad;
        bl_AdmobEvent.OnHandleAdClosing -= HandleAdClosing;
        bl_AdmobEvent.OnHandleAdClosed -= HandleAdClosed;
    }

    // Called when an ad request has successfully loaded.
    public void HandleAdLoaded(object sender, EventArgs args)
    {

    }

    // Called when an ad request failed to load.
    public void HandleAdFailedToLoad(object sender, AdFailedToLoadEventArgs args)
    {
      
    }

    // Called when an ad is clicked.
    public void HandleAdOpened(object sender, EventArgs args)
    {
      
    }
    // Called when the user is about to return to the app after an ad click.
    public void HandleAdClosing(object sender, EventArgs args)
    {
    
    }

    // Called when the user returned from the app after an ad click.
    public void HandleAdClosed(object sender, EventArgs args)
    {
      
    }

    // Called when the ad click caused the user to leave the application.
    public void HandleAdLeftApplication(object sender, EventArgs args)
    {
       
    }
}