﻿using UnityEngine;
using System.Collections.Generic;
using GoogleMobileAds.Api;
using System;
using UnityEngine.Advertisements;

public class bl_Admob : MonoBehaviour
{
    //Unit IDs
    public string ADSName = "New ADS";
    public string AndroidUnitID;
    public string IOSUnitID;
    public string UnityUnitID;
    public string IAPUnitID;

    public AdType m_AdType = AdType.Banner;
    public bool UseUnityAds = false;
    public bool ShowOnStart = true;
    public bool m_DontDestroyOnLoad = false;

    public AdSizeEnum Size = AdSizeEnum.Banner;
    public AdPosition Position = AdPosition.Top;

    public int Widht = 320;
    public int Height = 50;

    public string IAPPublicKey;
    public string[] Skus;

    public Gender GenderType;
    public bool ChildDirectedTreatment = false;
    public string Tags;

    public List<string> TestDevices = new List<string>();
    public bool useTestSimulator;

    private string UnitID;
    private BannerView m_BannerView;
    private InterstitialAd m_Interstitial;
    private bl_InAppPurchase m_InAppPurchase;

    public int MaxTryToAutoShow = 5;
    [HideInInspector]private int CountOfTry = 0;

    public bool Log = false;

    /// <summary>
    /// 
    /// </summary>
    void Start()
    {
        if (m_DontDestroyOnLoad)
        {
            DontDestroyOnLoad(gameObject);
        }
        if (UseUnityAds && !Advertisement.isInitialized)
        {
            Advertisement.Initialize(UnityUnitID);
        }
       
        if(m_AdType == AdType.InAppPurchase)
        {
            m_InAppPurchase = new bl_InAppPurchase();
            m_InAppPurchase.Init(Skus, IAPPublicKey);
            InitInterstitialIAP();
        }

        //If we want to prepare / show on start
        if (ShowOnStart)
        {
            if(m_AdType == AdType.Banner)
            {
                CreateBanner();
            }
            else
            {
                CreateInterstitial();
            }
        }
        gameObject.name = ADSName;
    }

    /// <summary>
    /// 
    /// </summary>
    void OnDestroy()
    {
        CancelInvoke();
    }

    /// <summary>
    /// 
    /// </summary>
    public void Show()
    {
        if (m_AdType == AdType.Banner)
        {
            ShowBanner();
        }
        else if (m_AdType == AdType.Interstitial)
        {
            ShowInterstitial();
        }
    }

    /// <summary>
    /// Call this when you need create or update the banner
    /// </summary>
    public void CreateBanner()
    {
        //if already created, then destroy it for update
        if(m_BannerView != null)
        {
            DestroyBanner();
            bl_LogText.LogText("Destroy Previous Banner");
        }
        GetUnityDevice();
        bl_LogText.LogText("GetDevice Unit: " + UnitID);      
        //Create the banner 
        m_BannerView = new BannerView(UnitID, GetAdSize(), Position);
        bl_LogText.LogText("Create View");
        //Add listener for receive events
        RegisterBannerEvents();
        // Load the banner with the request.
        m_BannerView.LoadAd(GetRequest);
        bl_LogText.LogText("Request Done");
    }

    /// <summary>
    /// 
    /// </summary>
    public bool RegisterNewTry(bool forUnity = false,float delay = 0)
    {
        if (MaxTryToAutoShow == 0)
            return false;

        CountOfTry = (CountOfTry + 1) % MaxTryToAutoShow;
        if (CountOfTry <= 0)
        {
            if (!forUnity)
            {
                Invoke("InvokeShow", delay);
            }
            else
            {
                Invoke("InvokeShowUnity", delay);
            }
            return true;
        }

        return false;
    }

    void InvokeShow() { Show(); }
    void InvokeShowUnity() { ShowUnityAd();  }

    /// <summary>
    /// Call this when you need hide the banner
    /// </summary>
    public void HideBanner()
    {
        if (m_BannerView == null)
            return;

        CancelInvoke();
        m_BannerView.Hide();
        bl_LogText.LogText("Hide Banner");
    }

    /// <summary>
    /// Call this when you need show the banner
    /// </summary>
    public void ShowBanner()
    {
        if (m_BannerView == null)
        {
            CreateBanner();
            return;
        }

        CancelInvoke();
        m_BannerView.Show();
        bl_LogText.LogText("Show Banner");
    }

    /// <summary>
    /// 
    /// </summary>
    public void FireInAppPurchase()
    {
        if (m_Interstitial != null)
        {
            m_Interstitial.SetInAppPurchaseHandler(m_InAppPurchase);
            bl_LogText.LogText("Call IAP");
        }
        else
        {
            bl_LogText.LogText("Can't call IAP due is not initializated!");
        }
    }

    /// <summary>
    /// 
    /// </summary>
    public void ShowUnityAd()
    {
        if (UseUnityAds)
        {
            if (Advertisement.IsReady())
            {
                Advertisement.Show();
            }
            else
            {
                Debug.LogWarning("UnityADS are not ready for show!");
                if (!Advertisement.isInitialized)
                {
                    Advertisement.Initialize(UnityUnitID);
                }
            }
        }
        else
        {
            Debug.LogWarning("This Ad not use unityAd");
        }
    }

    /// <summary>
    /// Call this when you need destroy the banner
    /// </summary>
    public void DestroyBanner()
    {
        if (m_BannerView == null)
            return;

        CancelInvoke();
        m_BannerView.Hide();
        m_BannerView.Destroy();
        m_BannerView = null;
        bl_LogText.LogText("Destroy Banner");
    }

    /// <summary>
    /// 
    /// </summary>
    public void Hide()
    {
        if (m_AdType == AdType.Banner)
        {
            HideBanner();
        }
        else if (m_AdType == AdType.Interstitial)
        {
            HideInterstitial(true);
        }
    }

    /// <summary>
    /// Call this for create a new interstitial.
    /// </summary>
    public void CreateInterstitial()
    {
        if(m_Interstitial != null)
        {
            HideInterstitial(true);
        }
        GetUnityDevice();
        bl_LogText.LogText("GetDevice Unit: " + UnitID);
        // Initialize an InterstitialAd.
        m_Interstitial = new InterstitialAd(UnitID);
        bl_LogText.LogText("Create Instertitial");
        //Register lsitener for reveive events
        RegisterInterstialEvent();
        // Load the interstitial with the request.
        m_Interstitial.LoadAd(GetRequest);
        bl_LogText.LogText("Create Instertitial Request Done.");
    }

    /// <summary>
    /// Call this for create a new interstitial.
    /// </summary>
    public void InitInterstitialIAP()
    {
        if (m_Interstitial != null)
        {
            HideInterstitial(false);
        }
        // Initialize an InterstitialAd.
        m_Interstitial = new InterstitialAd(IAPUnitID);
        RegisterInterstialEvent();
        bl_LogText.LogText("Initializated IAP");
    }

    /// <summary>
    /// 
    /// </summary>
    public void ChangeBannerPosition(AdPosition newpos)
    {
        if (m_BannerView == null)
            return;

        Position = newpos;
        CreateBanner();
    }

    /// <summary>
    /// Call this for show the interstitial
    /// </summary>
    public void ShowInterstitial()
    {
        if (m_Interstitial == null || !m_Interstitial.IsLoaded() )
        {
            bl_LogText.LogText("Create instertial,wait for show!");
            CreateInterstitial();
        }
        if (m_Interstitial != null && m_Interstitial.IsLoaded())
        {
            bl_LogText.LogText("Show Instertitial");
            m_Interstitial.Show();
        }
        else
        {
            bl_LogText.LogText("Instertitial is not loaded yet.");
            Debug.LogWarning("Interstitial is not loaded yet!");
        }
    }

    /// <summary>
    /// Call this for close the interstitial
    /// </summary>
    public void HideInterstitial(bool autoPrepare)
    {
        if (m_Interstitial == null)
            return;

        CancelInvoke();
        m_Interstitial.Destroy();
        m_Interstitial = null;
        if (autoPrepare)
        {
            CreateInterstitial();
        }
        bl_LogText.LogText("Destroy Instertitial");
    }

    /// <summary>
    /// 
    /// </summary>
    void OnGUI()
    {
        if (Log)
        {
            bl_LogText.DrawGUI();
        }
    }


    /// <summary>
    /// Create request for banner
    /// send all information 
    /// for get a banner according to our suggestions
    /// </summary>
    /// <returns></returns>
    private AdRequest GetRequest
    {
        get
        {
            // Creating the request builder
            AdRequest.Builder _request = new AdRequest.Builder();
            //add all test devices.
            foreach (string device in TestDevices)
            {
                //check if not null
                if (!string.IsNullOrEmpty(device))
                {
                    _request.AddTestDevice(device);
                }
            }
            //use Editor a test device?
            if (useTestSimulator)
            {
                _request.AddTestDevice(AdRequest.TestDeviceSimulator);
            }
            //Split all tags
            string[] alltags = Tags.Split(',');
            //send all tags
            foreach (string _tag in alltags)
            {
                if (_tag.Trim() != string.Empty)
                {
                    _request.AddKeyword(_tag.Trim());
                }
            }
            _request.SetGender(GenderType);
            _request.TagForChildDirectedTreatment(ChildDirectedTreatment);

            return _request.Build();
        }
    }

    /// <summary>
    /// Get the ADUnity depent of mobile target build
    /// </summary>
    private void GetUnityDevice()
    {
#if UNITY_ANDROID
		UnitID = AndroidUnitID;
#elif UNITY_IPHONE
		UnitID = IOSUnitID;
#else
        UnitID = "unexpected_platform";
#endif
    }

    /// <summary>
    /// 
    /// </summary>
    /// <returns></returns>
    private AdSize GetAdSize()
    {
        switch (Size)
        {
            case AdSizeEnum.Banner:
                return AdSize.Banner;
            case AdSizeEnum.IABBanner:
                return AdSize.IABBanner;
            case AdSizeEnum.Leaderboard:
                return AdSize.Leaderboard;
            case AdSizeEnum.MediumRectangle:
                return AdSize.MediumRectangle;
            case AdSizeEnum.SmartBanner:
                return AdSize.SmartBanner;
            case AdSizeEnum.Custom:
                AdSize ad = new AdSize(Widht, Height);
                return ad;
            default:
                return AdSize.Banner;
        }
    }

    /// <summary>
    /// 
    /// </summary>
    public BannerView GetBannerView
    {
        get
        {
            return m_BannerView;
        }
    }

    /// <summary>
    /// 
    /// </summary>
    public InterstitialAd GetInterstitial
    {
        get
        {
            return m_Interstitial;
        }
    }

    #region EventReceive

    /// <summary>
    /// 
    /// </summary>
    private void RegisterBannerEvents()
    {
        // Called when an ad request has successfully loaded.
        m_BannerView.AdLoaded += HandleAdLoaded;
        // Called when an ad request failed to load.
        m_BannerView.AdFailedToLoad += HandleAdFailedToLoad;
        // Called when an ad is clicked.
        m_BannerView.AdOpened += HandleAdOpened;
        // Called when the user is about to return to the app after an ad click.
        m_BannerView.AdClosing += HandleAdClosing;
        // Called when the user returned from the app after an ad click.
        m_BannerView.AdClosed += HandleAdClosed;
        // Called when the ad click caused the user to leave the application.
        m_BannerView.AdLeftApplication += HandleAdLeftApplication;
    }

    /// <summary>
    /// 
    /// </summary>
    private void RegisterInterstialEvent()
    {
        // Called when an ad request has successfully loaded.
        m_Interstitial.AdLoaded += HandleAdLoaded;
        // Called when an ad request failed to load.
        m_Interstitial.AdFailedToLoad += HandleAdFailedToLoad;
        // Called when an ad is clicked.
        m_Interstitial.AdOpened += HandleAdOpened;
        // Called when the user is about to return to the app after an ad click.
        m_Interstitial.AdClosing += HandleAdClosing;
        // Called when the user returned from the app after an ad click.
        m_Interstitial.AdClosed += HandleAdClosed;
        // Called when the ad click caused the user to leave the application.
        m_Interstitial.AdLeftApplication += HandleAdLeftApplication;
    }

    // Called when an ad request has successfully loaded.
    public void HandleAdLoaded(object sender, EventArgs args)
    {
        bl_AdmobEvent.HandleAdLoaded(sender, args);
    }

    // Called when an ad request failed to load.
    public void HandleAdFailedToLoad(object sender, AdFailedToLoadEventArgs args)
    {
        bl_AdmobEvent.HandleAdFailedToLoad(sender, args);
    }

    // Called when an ad is clicked.
    public void HandleAdOpened(object sender, EventArgs args)
    {
        bl_AdmobEvent.HandleAdOpened(sender, args);
    }
    // Called when the user is about to return to the app after an ad click.
    public void HandleAdClosing(object sender, EventArgs args)
    {
        bl_AdmobEvent.HandleAdClosing(sender, args);
    }

    // Called when the user returned from the app after an ad click.
    public void HandleAdClosed(object sender, EventArgs args)
    {
        bl_AdmobEvent.HandleAdClosed(sender, args);
        if(m_AdType == AdType.Interstitial)
        {
            CreateInterstitial();
        }
    }

    // Called when the ad click caused the user to leave the application.
    public void HandleAdLeftApplication(object sender, EventArgs args)
    {
        bl_AdmobEvent.HandleAdLeftApplication(sender, args);
    }
    #endregion
}