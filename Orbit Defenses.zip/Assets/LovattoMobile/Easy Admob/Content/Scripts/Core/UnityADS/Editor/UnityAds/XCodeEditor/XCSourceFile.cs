using UnityEngine;
using System.Collections;

namespace UnityEngine.Advertisements.XCodeEditor
{
	public class XCSourceFile : System.IDisposable
	{
		public void Dispose()
		{

		}
	}
}
