﻿using UnityEngine;
using UnityEditor;
using GoogleMobileAds.Api;
using UnityEditorInternal;

[CustomEditor(typeof(bl_Admob))]
public class bl_AdmobEditor : Editor
{
    private ReorderableList deviceList;
    private ReorderableList SkusList;

    void OnEnable()
    {       
        deviceList = new ReorderableList(serializedObject, serializedObject.FindProperty("TestDevices"), true, true, true, true);
        deviceList.drawHeaderCallback = HeaderDraw;
        deviceList.drawElementCallback = OnDrawList;

        SkusList = new ReorderableList(serializedObject, serializedObject.FindProperty("Skus"), true, true, true, true);
        SkusList.drawHeaderCallback = HeaderDrawSkus;
        SkusList.drawElementCallback = OnDrawListSkus;
    }

    public override void OnInspectorGUI()
    {
        bl_Admob myTarget = (bl_Admob)target;

        EditorGUILayout.Space();
        GUILayout.BeginVertical(EditorStyles.helpBox);
        EditorGUILayout.LabelField("Global Settings",EditorStyles.boldLabel);
        myTarget.ADSName = EditorGUILayout.TextField("Name: ", myTarget.ADSName);
        if (myTarget.m_AdType != AdType.InAppPurchase)
        {
            if (myTarget.UseUnityAds)
            {
                myTarget.UnityUnitID = EditorGUILayout.TextField("Unity AdUnit: ", myTarget.UnityUnitID);
            }
            myTarget.AndroidUnitID = EditorGUILayout.TextField("Android AdUnit: ", myTarget.AndroidUnitID);
            myTarget.IOSUnitID = EditorGUILayout.TextField("IOS AdUnit: ", myTarget.IOSUnitID);
        }
        else
        {
            myTarget.IAPUnitID = EditorGUILayout.TextField("IAP Unit: ", myTarget.IAPUnitID);
        }
        myTarget.m_AdType = (AdType)EditorGUILayout.EnumPopup("Ad Type:", myTarget.m_AdType);
        if (myTarget.m_AdType != AdType.InAppPurchase)
        {
            myTarget.UseUnityAds = EditorGUILayout.ToggleLeft("Use Unity ADS", myTarget.UseUnityAds, EditorStyles.toolbarButton);
        }
        myTarget.m_DontDestroyOnLoad = EditorGUILayout.ToggleLeft("Dont Destroy On Load", myTarget.m_DontDestroyOnLoad, EditorStyles.toolbarButton);
        GUILayout.EndVertical();

        GUILayout.BeginVertical(EditorStyles.helpBox);
        if (myTarget.m_AdType == AdType.Banner)
        {
            EditorGUILayout.LabelField("Banner Settings", EditorStyles.boldLabel);
            myTarget.Size = (AdSizeEnum)EditorGUILayout.EnumPopup("Banner Size", myTarget.Size);
            if (myTarget.Size == AdSizeEnum.Custom)
            {
                EditorGUILayout.BeginHorizontal();
                EditorGUILayout.LabelField("Width:", GUILayout.Width(50));
                myTarget.Widht = EditorGUILayout.IntField(myTarget.Widht);
                EditorGUILayout.LabelField("Height:", GUILayout.Width(50));
                myTarget.Height = EditorGUILayout.IntField(myTarget.Height);
                EditorGUILayout.EndHorizontal();
            }
            myTarget.Position = (AdPosition)EditorGUILayout.EnumPopup("Banner Position", myTarget.Position);
            myTarget.ShowOnStart = EditorGUILayout.ToggleLeft("Show on load", myTarget.ShowOnStart, EditorStyles.toolbarButton);
        }
        else if(myTarget.m_AdType == AdType.Interstitial)
        {
            EditorGUILayout.LabelField("Interstitial Settings", EditorStyles.boldLabel);
            myTarget.ShowOnStart = EditorGUILayout.ToggleLeft("Prepare on start", myTarget.ShowOnStart, EditorStyles.toolbarButton);
        }
        else
        {
            EditorGUILayout.LabelField("InAppPurchase Settings", EditorStyles.boldLabel);
            myTarget.IAPPublicKey = EditorGUILayout.TextField("Public Key:", myTarget.IAPPublicKey);
            serializedObject.Update();
            SkusList.DoLayoutList();
            serializedObject.ApplyModifiedProperties();
        }
        GUILayout.EndVertical();

       
            GUILayout.BeginVertical(EditorStyles.helpBox);
            EditorGUILayout.LabelField("Target Settings", EditorStyles.boldLabel);
        if (myTarget.m_AdType != AdType.InAppPurchase)
        {
            myTarget.GenderType = (Gender)EditorGUILayout.EnumPopup("Gender:", myTarget.GenderType);
            EditorGUILayout.LabelField("Tags (separate by ',')", EditorStyles.helpBox);
            myTarget.Tags = EditorGUILayout.TextArea(myTarget.Tags, GUILayout.Height(35));
            myTarget.ChildDirectedTreatment = EditorGUILayout.ToggleLeft(" Child-Directed Treatment (COPPA)", myTarget.ChildDirectedTreatment, EditorStyles.toolbarButton);
            GUILayout.EndVertical();

            GUILayout.BeginVertical(EditorStyles.helpBox);
            EditorGUILayout.LabelField("Device Settings", EditorStyles.boldLabel);
            serializedObject.Update();
            deviceList.DoLayoutList();
            serializedObject.ApplyModifiedProperties();
            myTarget.useTestSimulator = EditorGUILayout.ToggleLeft("Use editor as test simulator", myTarget.useTestSimulator, EditorStyles.toolbarButton);
            GUILayout.EndVertical();

            GUILayout.BeginVertical(EditorStyles.helpBox);
            EditorGUILayout.LabelField("Custom Settings", EditorStyles.boldLabel);
            myTarget.MaxTryToAutoShow = EditorGUILayout.IntSlider("Try To Auto Show:", myTarget.MaxTryToAutoShow, 0, 20);
        }
            myTarget.Log = EditorGUILayout.ToggleLeft("Logger this", myTarget.Log, EditorStyles.toolbarButton);
            GUILayout.EndVertical();
        

        if (GUI.changed)
        {
            EditorUtility.SetDirty(myTarget);
        }
    }

    void HeaderDraw(Rect rect)
    {
        EditorGUI.LabelField(rect, "Test Devices");
    }

    void OnDrawList(Rect rect, int index, bool isActive, bool isFocused)
    {
        var element = deviceList.serializedProperty.GetArrayElementAtIndex(index);
        rect.y += 2;
        EditorGUI.PropertyField(new Rect(rect.x, rect.y, rect.width - 50, EditorGUIUtility.singleLineHeight),element, GUIContent.none);
    }

    void HeaderDrawSkus(Rect rect)
    {
        EditorGUI.LabelField(rect, "IAP Skus");
    }

    void OnDrawListSkus(Rect rect, int index, bool isActive, bool isFocused)
    {
        var element = SkusList.serializedProperty.GetArrayElementAtIndex(index);
        rect.y += 2;
        EditorGUI.PropertyField(new Rect(rect.x, rect.y, rect.width - 50, EditorGUIUtility.singleLineHeight), element, GUIContent.none);
    }
}