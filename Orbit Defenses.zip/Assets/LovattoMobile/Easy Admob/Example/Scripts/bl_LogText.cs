﻿using UnityEngine;
using System;
using System.Collections.Generic;
using GoogleMobileAds.Api;

public class bl_LogText : MonoBehaviour {

    private static string m_LogText;
    private static List<string> ArrayString = new List<string>();
    private static int MaxMessages = 10;

    /// <summary>
    /// Add this script as listener for receive the events
    /// </summary>
    void OnEnable()
    {
        bl_AdmobEvent.OnHandleAdOpened += HandleAdOpened;
        bl_AdmobEvent.OnHandleAdLoaded += HandleAdLoaded;
        bl_AdmobEvent.OnHandleAdLeftApplication += HandleAdLeftApplication;
        bl_AdmobEvent.OnHandleAdFailedToLoad += HandleAdFailedToLoad;
        bl_AdmobEvent.OnHandleAdClosing += HandleAdClosing;
        bl_AdmobEvent.OnHandleAdClosed += HandleAdClosed;

    }

    /// <summary>
    /// When desactive this gameobject
    /// remove this listeners from event.
    /// </summary>
    void OnDisable()
    {
        bl_AdmobEvent.OnHandleAdOpened -= HandleAdOpened;
        bl_AdmobEvent.OnHandleAdLoaded -= HandleAdLoaded;
        bl_AdmobEvent.OnHandleAdLeftApplication -= HandleAdLeftApplication;
        bl_AdmobEvent.OnHandleAdFailedToLoad -= HandleAdFailedToLoad;
        bl_AdmobEvent.OnHandleAdClosing -= HandleAdClosing;
        bl_AdmobEvent.OnHandleAdClosed -= HandleAdClosed;
    }

    private static Vector2 LogScroll = Vector2.zero;
    public static void DrawGUI()
    {
        float width = (bl_AdmobUtils.IsMobile) ? 700 : 300;
        float height = (bl_AdmobUtils.IsMobile) ? 700 : 300;
        GUILayout.BeginArea(new Rect(5, 5, width, height));
        LogScroll = GUILayout.BeginScrollView(LogScroll);
        GUILayout.Label(m_LogText, LogStyle, GUILayout.Width(200), GUILayout.Height(500));
        GUILayout.EndScrollView();
        GUILayout.EndArea();
    }

    private static GUIStyle m_logStyle = null;
    private static GUIStyle LogStyle
    {
        get
        {
            if (m_logStyle == null)
            {
                m_logStyle = GUI.skin.label;
                int size = (bl_AdmobUtils.IsMobile) ? 15 : 8;
                m_logStyle.fontSize = size;
                m_logStyle.normal.textColor = new Color(1, 1, 1, 0.6f);
            }
            return m_logStyle;
        }
    }

    public static void LogText(string t)
    {
        ArrayString.Add(t);
        if(ArrayString.Count > MaxMessages)
        {
            ArrayString.RemoveAt(0);
        }
        m_LogText = "";
        foreach(string at in ArrayString)
        {
            m_LogText += at + "\n";
        }
        
    }

    // Called when an ad request has successfully loaded.
    public void HandleAdLoaded(object sender, EventArgs args)
    {
        m_LogText += "Request has successfully loaded \n";
    }

    // Called when an ad request failed to load.
    public void HandleAdFailedToLoad(object sender, AdFailedToLoadEventArgs args)
    {
        m_LogText += "failed to load, case:" + args.Message + " \n";
    }

    // Called when an ad is clicked.
    public void HandleAdOpened(object sender, EventArgs args)
    {
        m_LogText += "Click in ad \n";
    }
    // Called when the user is about to return to the app after an ad click.
    public void HandleAdClosing(object sender, EventArgs args)
    {
        m_LogText += "user about to return to the app after ad click. \n";
    }

    // Called when the user returned from the app after an ad click.
    public void HandleAdClosed(object sender, EventArgs args)
    {
        m_LogText += "the user returned from the app after ad click. \n";
    }

    // Called when the ad click caused the user to leave the application.
    public void HandleAdLeftApplication(object sender, EventArgs args)
    {
        m_LogText += "leave the application by ad click \n";
    }
}