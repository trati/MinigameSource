﻿using UnityEngine;
using UnityEngine.UI;

public class bl_AdmobExample : MonoBehaviour {

    public bl_Admob Banner;
    public bl_Admob Interstitial;
    [Header("Buttons")]
    [SerializeField]private Button ShowBannerButton;
    [SerializeField]private Button HideBannerButton;
    [SerializeField]private Button DestroyBannerButton;
    [SerializeField]private Button ShowInterstitialButton;
    [SerializeField]private Button DestroyInterstitialButton;


    public void RequestBanner()
    {
        Banner.CreateBanner();
        ShowBannerButton.interactable = true;
        DestroyBannerButton.interactable = true;
    }

    public void ShowBanner()
    {
        Banner.ShowBanner();
        HideBannerButton.interactable = true;
        ShowBannerButton.interactable = false;
    }

    public void HideBanner()
    {
        Banner.HideBanner();
        HideBannerButton.interactable = false;
        ShowBannerButton.interactable = true;
    }

    public void DestroyBanner()
    {
        Banner.DestroyBanner();
        HideBannerButton.interactable = false;
        ShowBannerButton.interactable = false;
    }

    public void RequestInterstitial()
    {
        Interstitial.CreateInterstitial();
        ShowInterstitialButton.interactable = true;
        DestroyInterstitialButton.interactable = true;
    }

    public void ShowInterstitial()
    {
        Interstitial.ShowInterstitial();
        ShowInterstitialButton.interactable = false;
    }

    public void DestroyInterstitial()
    {
        Interstitial.HideInterstitial(true);
        ShowInterstitialButton.interactable = false;
        DestroyInterstitialButton.interactable = false;
    }
}