Thanks for purchase Orbit Defense Game Template.

For the documentation please unzip the file "documentation.rar" out side of the Unity project for avoid problems with the files
of the documentation.

Contact Us:
lovattostudio@gmail.com