﻿////////////////////////////////////////////////////////////////////////////
// KeyMaster
//
//
//                    Lovatto Studio 2016
////////////////////////////////////////////////////////////////////////////

public class KeyMaster
{
    public const string BestScore = "com.lovattostudio.orbitplane.bestscore";
    public const string AudioEnable = "com.lovattostudio.orbitplane.audioenable";
}