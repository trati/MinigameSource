﻿////////////////////////////////////////////////////////////////////////////
// bl_GameManager
//
//
//                    Lovatto Studio 2016
////////////////////////////////////////////////////////////////////////////
using UnityEngine;
using UnityEngine.UI;

public class bl_GameManager : Singleton<bl_GameManager>
{
    [HideInInspector]public bool isPlaying = false;

    [Header("References")]
    [SerializeField]private Animator MainAnim;
    [SerializeField]private Image AudioIconImage;
    [SerializeField]private Sprite AudioOnSprite;
    [SerializeField]private Sprite AudioOffSprite;
    [SerializeField]private Animator GameOverAnim;
    [SerializeField]private GameObject PlayButton;//we need show only one time this, so will desactive after use it.
    [SerializeField]private Button[] PlayServiceButtons;
    [SerializeField]private GameObject[] ExtraDefenses;
    public Transform FloatingParent;

    [Header("Backgrounds")]
    [SerializeField]private SpriteRenderer BackgroundRender;
    [SerializeField]private Color[] BackgroundsColors;

    private bool audioOn = true;
    private bl_Admob BannerAd;
    private bl_Admob InterstitialAd;

    /// <summary>
    /// 
    /// </summary>
    void Start()
    {
        LoadSettings();
        BannerAd = bl_AdmobUtils.GetAdmob("Banner");
        InterstitialAd = bl_AdmobUtils.GetAdmob("Interstitial");
        foreach (Button b in PlayServiceButtons)
        {
            b.interactable = false;
            Image[] imgs = b.GetComponentsInChildren<Image>();
            imgs[1].color = b.colors.disabledColor;
        }
        ChangeBackground();
    }

    /// <summary>
    /// 
    /// </summary>
    void LoadSettings()
    {
        audioOn = bl_Utils.PlayerPrefsX.GetBool(KeyMaster.AudioEnable, true);
        AudioIconImage.sprite = (audioOn) ? AudioOnSprite : AudioOffSprite;
        AudioListener.pause = !audioOn;

        MainAnim.gameObject.SetActive(true);
        MainAnim.SetBool("show", true);
    }

    /// <summary>
    /// 
    /// </summary>
    public void Share()
    {
        StartCoroutine(bl_LovattoMobileUtils.TakeScreenShotAndShare(0));
    }

    /// <summary>
    /// 
    /// </summary>
    public void OnGameOver()
    {
        isPlaying = false;
        PlayButton.SetActive(false);
        MainAnim.gameObject.SetActive(true);
        MainAnim.SetBool("show", true);
        GameOverAnim.gameObject.SetActive(true);
        GameOverAnim.SetBool("show", true);
        bl_SpawnerManager.Instance.HideAll();
        bl_ScoreManager.Instance.Reset();
        BannerAd.ShowBanner();
        InterstitialAd.RegisterNewTry(false,0.5f);
    }

    /// <summary>
    /// 
    /// </summary>
    public void PlayServiceLogin()
    {
        foreach (Button b in PlayServiceButtons)
        {
            b.interactable = true;
            Image[] imgs = b.GetComponentsInChildren<Image>();
            imgs[1].color = b.colors.normalColor;
        }
    }

    /// <summary>
    /// /
    /// </summary>
    public void TryAgain()
    {
        if (isPlaying)
            return;

        bl_TimeManager.Instance.SetSlowMotion(false);
        MainAnim.SetBool("show", false);
        StartCoroutine(bl_Utils.AnimatorUtils.WaitAnimationLenghtForDesactive(MainAnim));
        GameOverAnim.SetBool("show", false);
        StartCoroutine(bl_Utils.AnimatorUtils.WaitAnimationLenghtForDesactive(GameOverAnim));
        ChangeBackground();
        bl_Planet.Instance.Reset();
        bl_SpawnerManager.Instance.Spawn();
        foreach(GameObject g in ExtraDefenses) { g.SetActive(true); }
        if (BannerAd) { BannerAd.HideBanner(); }

        isPlaying = true;
    }

    void ChangeBackground()
    {
        BackgroundRender.color = BackgroundsColors[Random.Range(0, BackgroundsColors.Length)];
    }

    /// <summary>
    /// 
    /// </summary>
    public void StartGame()
    {
        isPlaying = true;
    }

    /// <summary>
    /// 
    /// </summary>
    public void SwitchAudio()
    {
        audioOn = !audioOn;
        AudioIconImage.sprite = (audioOn) ? AudioOnSprite : AudioOffSprite;
        AudioListener.pause = !audioOn;
        bl_Utils.PlayerPrefsX.SetBool(KeyMaster.AudioEnable, audioOn);
    }

    public static bl_GameManager Instance
    {
        get
        {
            return ((bl_GameManager)mInstance);
        }
        set
        {
            mInstance = value;
        }
    }
}