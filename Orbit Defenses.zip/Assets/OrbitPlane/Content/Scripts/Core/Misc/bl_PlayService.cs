﻿////////////////////////////////////////////////////////////////////////////
// bl_PlayService
//
//
//                    Lovatto Studio 2016
////////////////////////////////////////////////////////////////////////////
using UnityEngine;
using GooglePlayGames;
using GooglePlayGames.BasicApi;
using UnityEngine.SocialPlatforms;

public class bl_PlayService : Singleton<bl_PlayService>
{
    public bool AuthentictatedOnStart = false;

    void Start()
    {
       // PlayGamesPlatform.DebugLogEnabled = true;
        // Set the default leaderboard for the leaderboards UI
        PlayGamesPlatform.Instance.SetDefaultLeaderboardForUI(PlayServiceKey.leaderboard_ranking);
        PlayGamesPlatform.Activate();

        if (AuthentictatedOnStart)
        {
            Authenticated();
        }
    }

    /// <summary>
    /// 
    /// </summary>
    public void Authenticated()
    {
        
        if (!Social.Active.localUser.authenticated)
        {
            Social.Active.localUser.Authenticate(ProcessAuth);
        }
        else
        {
            Debug.Log("Already Login");
        }
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="succes"></param>
    void ProcessAuth(bool succes)
    {
        if (succes)
        {
            bl_GameManager.Instance.PlayServiceLogin();
            //string token = GooglePlayGames.PlayGamesPlatform.Instance.GetToken();
            Debug.Log("Success Login");
        }
        else
        {
            Debug.Log("Fail to Login");
        }
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="score"></param>
    /// <returns></returns>
    public bool SetScoreToLeaderBoard(int score)
    {
        bool b = false;
        if (isAuthenticated)
        {
            Social.Active.ReportScore(score, PlayServiceKey.leaderboard_ranking, (bool success) =>
            {
                b = success;
            });
        }
        return b;
    }

    /// <summary>
    /// 
    /// </summary>
    public void SignOut()
    {
        if (!Social.Active.localUser.authenticated)
            return;

        PlayGamesPlatform.Instance.SignOut();
    }

    /// <summary>
    /// 
    /// </summary>
    public void ShowLeaderBoard()
    {
        if (Social.Active.localUser.authenticated)
        {
            // PlayGamesPlatform.Instance.ShowLeaderboardUI(PlayClassKey.leaderboard_ranking);
            Social.Active.ShowLeaderboardUI();
        }
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="ID"></param>
    public void ShotThisLeaderboard(string ID)
    {
        PlayGamesPlatform.Instance.ShowLeaderboardUI(ID);
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="ID"></param>
    public void UnlockAchievement(string ID)
    {
        if (isAuthenticated)
        {
            Social.Active.ReportProgress(ID, 100.0f, (bool success) =>
        {
            // handle success or failure
        });
        }
    }

    /// <summary>
    /// 
    /// </summary>
    public void ShowAchievement()
    {
        // show achievements UI
        Social.Active.ShowAchievementsUI();
    }

    public bool isAuthenticated
    {
        get
        {
            return Social.Active.localUser.authenticated;
        }
    }

    public static bl_PlayService Instance
    {
        get
        {
            return ((bl_PlayService)mInstance);
        }
        set
        {
            mInstance = value;
        }
    }
}