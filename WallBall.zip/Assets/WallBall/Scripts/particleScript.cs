﻿using UnityEngine;
using System.Collections;

public class particleScript : MonoBehaviour {

	// Use this for initialization
	void Start () {
		Destroy (this.gameObject, 1f);
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
