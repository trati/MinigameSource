Wall Ball

---------

Hello and thanks for buying "Wall Ball".
This project contains a complete endless runner game.

Just start the scene "Wall Ball" in the folder scenes. 
The source code is heavily commented to help you to extend it.


If you have any issues with the project, just drop me line at office@gemmine.de.
If you have any wishes for further development, just drop me line at office@gemmine.de.
And: if you like the game, please rate the project. I'd really appreciate that.


You can play the game at http://www.gemmine.de/de/wallball.html
